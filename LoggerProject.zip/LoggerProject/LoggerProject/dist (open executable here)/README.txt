Click the executable found here, called "keylogger" and it will begin recording your keyboard's inputs. (It will not show that it has begun recording, this is to be discrete)
Press the escape key to end keylogging.
Check the keyboard logs in a .txt or called "keylog", which will be generated here once you use the executable once.